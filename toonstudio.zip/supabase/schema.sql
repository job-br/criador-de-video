-- Rode no Supabase: SQL Editor > New query > Run
create table profiles(id uuid primary key references auth.users on delete cascade, credits int not null default 10 check (credits >= 0));
create table projects(id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, title text, style text, size text, merged_url text, created_at timestamptz default now());
create table jobs(id uuid primary key default gen_random_uuid(), user_id uuid references auth.users on delete cascade, project_id uuid references projects on delete cascade, scene_idx int, prompt text, seconds int, worker_id text, status text default 'queued', url text, error text, progress int default 0, total int default 1, cost int, created_at timestamptz default now());
create table payments(session_id text primary key, user_id uuid, credits int, created_at timestamptz default now());

-- Tudo bloqueado para o público; só as Functions (service_role) acessam.
alter table profiles enable row level security;
alter table projects enable row level security;
alter table jobs enable row level security;
alter table payments enable row level security;

create function handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into profiles(id) values (new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create function spend_credits(uid uuid, amt int) returns boolean language plpgsql security definer as $$
begin update profiles set credits = credits - amt where id = uid and credits >= amt; return found; end $$;

create function add_credits(uid uuid, amt int, sid text default null) returns boolean language plpgsql security definer as $$
begin
  if sid is not null then
    insert into payments(session_id, user_id, credits) values (sid, uid, amt) on conflict do nothing;
    if not found then return false; end if;
  end if;
  update profiles set credits = credits + amt where id = uid; return true;
end $$;

revoke execute on function spend_credits(uuid,int), add_credits(uuid,int,text) from public, anon, authenticated;
