-- Rode apenas se você JÁ tinha criado o banco da versão anterior
alter table jobs add column if not exists progress int default 0;
alter table jobs add column if not exists total int default 1;
alter table jobs add column if not exists cost int;
