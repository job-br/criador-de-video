import { json, PACKS } from "../lib/lib.js";
export default async () => json({ url: process.env.SUPABASE_URL, anon: process.env.SUPABASE_ANON_KEY, packs: PACKS });
