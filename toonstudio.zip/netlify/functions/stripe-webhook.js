// Stripe > Developers > Webhooks > endpoint: https://SEU-SITE/api/stripe-webhook  (evento: checkout.session.completed)
import crypto from "node:crypto";
import { rpc, json } from "../lib/lib.js";
export default async (req) => {
  const raw = await req.text();
  const h = Object.fromEntries((req.headers.get("stripe-signature") || "").split(",").map((x) => x.split("=")));
  const sig = crypto.createHmac("sha256", process.env.STRIPE_WEBHOOK_SECRET).update(`${h.t}.${raw}`).digest("hex");
  const ok = h.v1 && h.v1.length === sig.length && crypto.timingSafeEqual(Buffer.from(h.v1), Buffer.from(sig));
  if (!ok || Math.abs(Date.now() / 1000 - Number(h.t)) > 300) return json({ error: "assinatura inválida" }, 400);
  const ev = JSON.parse(raw);
  if (ev.type === "checkout.session.completed") {
    const s = ev.data.object;
    if (s.payment_status === "paid" && s.metadata?.user_id)
      await rpc("add_credits", { uid: s.metadata.user_id, amt: Number(s.metadata.credits), sid: s.id });
  }
  return json({ received: true });
};
