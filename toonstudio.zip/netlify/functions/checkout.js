import { user, json, PACKS } from "../lib/lib.js";
export default async (req) => {
  const u = await user(req);
  if (!u) return json({ error: "Faça login" }, 401);
  const { pack } = await req.json();
  const p = PACKS[pack];
  if (!p) return json({ error: "Pacote inválido" }, 400);
  const origin = new URL(req.url).origin;
  const f = new URLSearchParams({
    mode: "payment", success_url: `${origin}/?paid=1`, cancel_url: origin,
    customer_email: u.email,
    "line_items[0][quantity]": "1", "line_items[0][price_data][currency]": "brl",
    "line_items[0][price_data][unit_amount]": String(p.price),
    "line_items[0][price_data][product_data][name]": `ToonStudio – ${p.name}`,
    "metadata[user_id]": u.id, "metadata[credits]": String(p.credits),
  });
  const r = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST", headers: { Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`, "Content-Type": "application/x-www-form-urlencoded" }, body: f,
  });
  const d = await r.json();
  return r.ok ? json({ url: d.url }) : json({ error: d.error?.message || "Stripe" }, 502);
};
