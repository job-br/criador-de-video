// Proxy seguro: o navegador nunca vê a chave do servidor GPU.
export default async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  if (req.headers.get("x-app-key") !== process.env.APP_PASSWORD)
    return Response.json({ error: "Senha inválida" }, { status: 401 });

  const b = await req.json();
  const payload = {
    prompt: String(b.prompt || "").slice(0, 1500),
    style: b.style || "3d",
    seconds: Math.min(Math.max(Number(b.seconds) || 5, 2), 10),
    size: b.size === "720p" ? "1280*704" : "704*1280",
  };
  if (!payload.prompt) return Response.json({ error: "Prompt vazio" }, { status: 400 });

  const r = await fetch(`${process.env.GPU_API_URL}/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.GPU_API_KEY}` },
    body: JSON.stringify(payload),
  });
  return Response.json(await r.json(), { status: r.status });
};
