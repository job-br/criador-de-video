import { sb, rpc, user, gpu, json } from "../lib/lib.js";
const clamp = (v, a, b, d) => Math.min(Math.max(Number(v) || d, a), b);
export default async (req) => {
  const u = await user(req);
  if (!u) return json({ error: "Faça login" }, 401);
  const b = await req.json();
  const quality = b.quality === "max" ? "max" : "std", mult = quality === "max" ? 2 : 1;

  // item = { segments:[prompts de 5s] }  ou  { prompt, seconds } (dividido automaticamente em partes de 5s)
  const items = (b.items || []).slice(0, 40).map((it) => {
    if (Array.isArray(it.segments)) {
      const segs = it.segments.map((s) => String(s).trim().slice(0, 3000)).filter(Boolean).slice(0, 36);
      return segs.length ? { segments: segs, n: segs.length, prompt: segs[0] } : null;
    }
    const prompt = String(it.prompt || "").trim().slice(0, 8000);
    return prompt ? { prompt, n: clamp(Math.ceil((Number(it.seconds) || 5) / 5), 1, 36, 1) } : null;
  }).filter(Boolean);
  if (!items.length) return json({ error: "Adicione ao menos uma cena" }, 400);

  const style = String(b.style || "").slice(0, 600);
  const character = String(b.character || "").slice(0, 1500);
  const size = b.size === "vertical" ? "704*1280" : "1280*704";
  const image = typeof b.image === "string" && b.image.length < 7_000_000 ? b.image : null;
  const admin = (process.env.ADMIN_EMAILS || "").toLowerCase().split(",").map((s) => s.trim()).includes((u.email || "").toLowerCase());
  const cost = items.reduce((a, i) => a + i.n * 5, 0) * mult;

  let imageId = null;
  if (image) {
    try { imageId = (await (await gpu("/assets", { method: "POST", body: JSON.stringify({ image }) })).json()).id; } catch {}
    if (!imageId) return json({ error: "Servidor GPU indisponível" }, 502);
  }
  if (!admin && !(await rpc("spend_credits", { uid: u.id, amt: cost }))) return json({ error: `Créditos insuficientes (precisa de ${cost})` }, 402);

  const [proj] = await sb("projects", { method: "POST", body: JSON.stringify({ user_id: u.id, title: String(b.title || "Sem título").slice(0, 80), style: style.slice(0, 60), size }) });
  for (let i = 0; i < items.length; i++) {
    const it = items[i], c = admin ? 0 : it.n * 5 * mult;
    const row = { user_id: u.id, project_id: proj.id, scene_idx: i, prompt: it.prompt.slice(0, 500), seconds: it.n * 5, total: it.n, cost: c, status: "queued" };
    try {
      const body = { seconds: it.n * 5, size, style, quality, image_id: imageId };
      if (it.segments) body.segments = it.segments.map((s) => [character, s].filter(Boolean).join(". "));
      else body.prompt = [character, it.prompt].filter(Boolean).join(". ");
      const r = await gpu("/jobs", { method: "POST", body: JSON.stringify(body) });
      if (!r.ok) throw new Error();
      row.worker_id = (await r.json()).id;
    } catch {
      row.status = "error"; row.error = "Servidor GPU indisponível";
      if (c) await rpc("add_credits", { uid: u.id, amt: c });
    }
    await sb("jobs", { method: "POST", body: JSON.stringify(row) });
  }
  return json({ project: proj.id });
};
