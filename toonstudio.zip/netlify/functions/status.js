import { sb, rpc, user, gpu, json } from "../lib/lib.js";
export default async (req) => {
  const u = await user(req);
  if (!u) return json({ error: "Faça login" }, 401);
  const jobs = await sb(`jobs?user_id=eq.${u.id}&order=created_at.desc&limit=500`);
  await Promise.all(jobs.filter((j) => j.status === "queued" || j.status === "running").map(async (j) => {
    try {
      const d = await (await gpu(`/jobs/${j.worker_id}`)).json();
      if (d.status === j.status && (d.progress ?? 0) === (j.progress ?? 0)) return;
      const patch = { status: d.status, progress: d.progress ?? j.progress, url: d.url || null, error: d.error || null };
      const rows = await sb(`jobs?id=eq.${j.id}&status=in.(queued,running)`, { method: "PATCH", body: JSON.stringify(patch) });
      if (rows.length && d.status === "error" && j.cost > 0) await rpc("add_credits", { uid: u.id, amt: j.cost }); // reembolso único
      Object.assign(j, patch);
    } catch {}
  }));
  const [p] = await sb(`profiles?id=eq.${u.id}`);
  const projects = await sb(`projects?user_id=eq.${u.id}&order=created_at.desc&limit=50`);
  return json({ credits: p?.credits ?? 0, projects, jobs });
};
