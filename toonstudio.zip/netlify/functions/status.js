export default async (req) => {
  if (req.headers.get("x-app-key") !== process.env.APP_PASSWORD)
    return Response.json({ error: "Senha inválida" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("id");
  const r = await fetch(`${process.env.GPU_API_URL}/jobs/${encodeURIComponent(id)}`, {
    headers: { Authorization: `Bearer ${process.env.GPU_API_KEY}` },
  });
  return Response.json(await r.json(), { status: r.status });
};
