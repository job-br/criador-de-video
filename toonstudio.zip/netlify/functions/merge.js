import { sb, user, gpu, json } from "../lib/lib.js";
export default async (req) => {
  const u = await user(req);
  if (!u) return json({ error: "Faça login" }, 401);
  const { projectId } = await req.json();
  const jobs = await sb(`jobs?project_id=eq.${projectId}&user_id=eq.${u.id}&order=scene_idx.asc`);
  if (!jobs.length || jobs.some((j) => j.status !== "done")) return json({ error: "Aguarde todas as cenas ficarem prontas" }, 400);
  const r = await gpu("/merge", { method: "POST", body: JSON.stringify({ ids: jobs.map((j) => j.worker_id) }) });
  const d = await r.json();
  if (!r.ok) return json({ error: "Falha ao juntar cenas" }, 502);
  await sb(`projects?id=eq.${projectId}&user_id=eq.${u.id}`, { method: "PATCH", body: JSON.stringify({ merged_url: d.url }) });
  return json({ url: d.url });
};
