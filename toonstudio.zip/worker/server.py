"""Worker GPU: roda o Wan 2.2 de verdade (RunPod / Modal / VM com GPU).
Pré-requisito: clonar Wan2.2, instalar o requirements dele e baixar os pesos TI2V-5B (~24GB VRAM)."""
import os, uuid, subprocess, threading
from fastapi import FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles

KEY = os.environ["GPU_API_KEY"]
WAN_DIR = os.environ.get("WAN_DIR", "./Wan2.2")
CKPT = os.environ.get("WAN_CKPT", "./Wan2.2-TI2V-5B")
PUBLIC = os.environ["PUBLIC_URL"]  # ex: https://seu-worker.exemplo.com
os.makedirs("outputs", exist_ok=True)

STYLES = {
  "3d": "colorful 3D animated kids cartoon, soft lighting, cute rounded characters, vibrant colors, high quality",
  "2d": "2D hand-drawn children's animation, bright flat colors, friendly characters, smooth motion",
  "massinha": "claymation stop-motion style, soft clay textures, cheerful, children's show",
  "aquarela": "watercolor storybook animation, gentle pastel palette, whimsical, for children",
}
app = FastAPI()
jobs = {}
lock = threading.Lock()  # uma geração por vez por GPU

def auth(a):
    if a != f"Bearer {KEY}":
        raise HTTPException(401)

def run(jid, p):
    with lock:
        jobs[jid]["status"] = "running"
        frames = 4 * round(p["seconds"] * 24 / 4) + 1
        out = os.path.abspath(f"outputs/{jid}.mp4")
        prompt = f'{p["prompt"]}, {STYLES.get(p["style"], STYLES["3d"])}'
        cmd = ["python", "generate.py", "--task", "ti2v-5B", "--size", p["size"],
               "--ckpt_dir", CKPT, "--offload_model", "True", "--convert_model_dtype",
               "--t5_cpu", "--frame_num", str(frames), "--prompt", prompt, "--save_file", out]
        try:
            subprocess.run(cmd, cwd=WAN_DIR, check=True)
            jobs[jid].update(status="done", url=f"{PUBLIC}/videos/{jid}.mp4")
        except Exception as e:
            jobs[jid].update(status="error", error=str(e))

@app.post("/jobs")
def create(p: dict, authorization: str = Header("")):
    auth(authorization)
    jid = uuid.uuid4().hex[:10]
    jobs[jid] = {"id": jid, "status": "queued"}
    threading.Thread(target=run, args=(jid, p), daemon=True).start()
    return jobs[jid]

@app.get("/jobs/{jid}")
def get(jid: str, authorization: str = Header("")):
    auth(authorization)
    return jobs.get(jid) or {"status": "error", "error": "não encontrado"}

app.mount("/videos", StaticFiles(directory="outputs"), name="videos")
# Rodar: uvicorn server:app --host 0.0.0.0 --port 8000
